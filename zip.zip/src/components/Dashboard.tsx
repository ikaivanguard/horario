import React, { useState } from 'react';
import { User } from '../types';
import { LogOut, Calendar, MessageSquare, Shield } from 'lucide-react';
import FeedbackModule from './FeedbackModule';
import SchedulerModule from './SchedulerModule';

interface DashboardProps {
  user: User;
  onLogout: () => void;
}

export default function Dashboard({ user, onLogout }: DashboardProps) {
  const [activeTab, setActiveTab] = useState<'scheduler' | 'feedback'>('scheduler');

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-[#141414]/80 backdrop-blur-md border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-indigo-500/10 rounded-xl ring-1 ring-indigo-500/20">
                <Shield className="w-6 h-6 text-indigo-400" />
              </div>
              <h1 className="text-xl font-bold tracking-tight text-white hidden sm:block">
                Ikai Vanguard
              </h1>
            </div>

            <div className="flex items-center gap-2 sm:gap-6">
              <div className="flex bg-[#0a0a0a] p-1 rounded-xl border border-white/5">
                <button
                  onClick={() => setActiveTab('scheduler')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    activeTab === 'scheduler'
                      ? 'bg-indigo-500/20 text-indigo-300'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Calendar className="w-4 h-4" />
                  <span className="hidden sm:inline">Cronograma</span>
                </button>
                <button
                  onClick={() => setActiveTab('feedback')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    activeTab === 'feedback'
                      ? 'bg-indigo-500/20 text-indigo-300'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <MessageSquare className="w-4 h-4" />
                  <span className="hidden sm:inline">Feedback</span>
                </button>
              </div>

              <div className="h-6 w-px bg-white/10 hidden sm:block"></div>

              <div className="flex items-center gap-4">
                <div className="text-sm text-gray-400 hidden sm:block">
                  Admin: <span className="text-white font-medium">{user.username}</span>
                </div>
                <button
                  onClick={onLogout}
                  className="p-2 text-gray-400 hover:text-red-400 hover:bg-red-500/10 rounded-xl transition-colors"
                  title="Cerrar Sesión"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'scheduler' ? <SchedulerModule user={user} /> : <FeedbackModule user={user} />}
      </main>
    </div>
  );
}
