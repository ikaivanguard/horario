import React, { useState, useEffect } from 'react';
import { User, Feedback } from '../types';
import { Send, CheckCircle2, Clock, AlertCircle, MessageSquare } from 'lucide-react';

interface FeedbackModuleProps {
  user: User;
}

export default function FeedbackModule({ user }: FeedbackModuleProps) {
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Moderación');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);

  const fetchFeedbacks = async () => {
    try {
      const res = await fetch('/api/feedback');
      const data = await res.json();
      setFeedbacks(data);
    } catch (e) {
      console.error('Error fetching feedbacks', e);
    }
  };

  useEffect(() => {
    fetchFeedbacks();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, category, description, user_id: user.id }),
      });
      setTitle('');
      setDescription('');
      fetchFeedbacks();
    } catch (e) {
      console.error('Error submitting feedback', e);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (id: number, status: string) => {
    try {
      await fetch(`/api/feedback/${id}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      fetchFeedbacks();
    } catch (e) {
      console.error('Error updating status', e);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Implementada':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
      case 'En Revisión':
        return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
      default:
        return 'bg-gray-500/10 text-gray-400 border-gray-500/20';
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Form */}
      <div className="lg:col-span-1">
        <div className="bg-[#141414] border border-white/5 rounded-3xl p-6 sticky top-24">
          <h2 className="text-lg font-semibold text-white mb-6">Nueva Propuesta</h2>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-xs font-medium text-gray-400 uppercase tracking-wider mb-2">
                Título
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="block w-full px-4 py-3 bg-[#0a0a0a] border border-white/10 rounded-xl text-white placeholder-gray-600 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                placeholder="Breve descripción..."
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-400 uppercase tracking-wider mb-2">
                Categoría
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="block w-full px-4 py-3 bg-[#0a0a0a] border border-white/10 rounded-xl text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
              >
                <option value="Moderación">Moderación</option>
                <option value="Dinámicas">Dinámicas</option>
                <option value="Alianzas">Alianzas</option>
                <option value="Otros">Otros</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-400 uppercase tracking-wider mb-2">
                Descripción Detallada
              </label>
              <textarea
                required
                rows={4}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="block w-full px-4 py-3 bg-[#0a0a0a] border border-white/10 rounded-xl text-white placeholder-gray-600 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all resize-none"
                placeholder="Explica tu propuesta..."
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 px-4 flex justify-center items-center gap-2 text-sm font-semibold rounded-xl text-white bg-indigo-600 hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 focus:ring-offset-[#141414] transition-all disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
              {loading ? 'Enviando...' : 'Enviar Propuesta'}
            </button>
          </form>
        </div>
      </div>

      {/* List */}
      <div className="lg:col-span-2 space-y-4">
        <h2 className="text-lg font-semibold text-white mb-6">Propuestas Recientes</h2>
        {feedbacks.length === 0 ? (
          <div className="text-center py-16 bg-[#141414] border border-white/5 rounded-3xl">
            <MessageSquare className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400">No hay propuestas aún.</p>
          </div>
        ) : (
          feedbacks.map((fb) => (
            <div key={fb.id} className="bg-[#141414] border border-white/5 rounded-3xl p-6 hover:border-white/10 transition-colors">
              <div className="flex flex-col sm:flex-row justify-between items-start gap-4 mb-4">
                <div>
                  <h3 className="text-lg font-medium text-white">{fb.title}</h3>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-sm text-gray-500">Por {fb.username}</span>
                    <span className="text-xs text-gray-700">•</span>
                    <span className="text-xs font-medium text-indigo-400 bg-indigo-500/10 px-2.5 py-1 rounded-full">
                      {fb.category}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <select
                    value={fb.status}
                    onChange={(e) => handleStatusChange(fb.id, e.target.value)}
                    className={`w-full sm:w-auto text-xs font-medium px-3 py-1.5 rounded-full border appearance-none cursor-pointer focus:outline-none ${getStatusColor(fb.status)}`}
                  >
                    <option value="Pendiente">Pendiente</option>
                    <option value="En Revisión">En Revisión</option>
                    <option value="Implementada">Implementada</option>
                  </select>
                </div>
              </div>
              <p className="text-sm text-gray-400 whitespace-pre-wrap leading-relaxed">{fb.description}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
