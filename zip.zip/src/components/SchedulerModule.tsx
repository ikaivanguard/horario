import React, { useState, useEffect } from 'react';
import { User, ScheduleBlock } from '../types';
import { Download, Loader2 } from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface SchedulerModuleProps {
  user: User;
}

const DAYS = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
const HOURS = Array.from({ length: 16 }, (_, i) => i + 7); // 7 to 22

const formatHour = (h: number) => {
  const ampm = h >= 12 ? 'PM' : 'AM';
  const hour12 = h % 12 || 12;
  return `${hour12}:00 ${ampm}`;
};

export default function SchedulerModule({ user }: SchedulerModuleProps) {
  const [schedule, setSchedule] = useState<ScheduleBlock[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<{day: number, hour: number} | null>(null);

  const fetchSchedule = async () => {
    try {
      const res = await fetch('/api/schedule');
      const data = await res.json();
      setSchedule(data);
    } catch (e) {
      console.error('Error fetching schedule', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSchedule();
    const interval = setInterval(fetchSchedule, 5000);
    return () => clearInterval(interval);
  }, []);

  const toggleAssignment = async (day: number, hour: number, isAssigned: boolean) => {
    setActionLoading({ day, hour });
    try {
      if (isAssigned) {
        await fetch('/api/schedule', {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ day, hour, user_id: user.id }),
        });
      } else {
        await fetch('/api/schedule', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ day, hour, user_id: user.id }),
        });
      }
      await fetchSchedule();
    } catch (e) {
      console.error('Error toggling assignment', e);
    } finally {
      setActionLoading(null);
    }
  };

  const generatePDF = () => {
    const doc = new jsPDF({ orientation: 'landscape' });
    
    doc.setFontSize(18);
    doc.text('Ikai Vanguard - Cronograma Semanal', 14, 22);
    doc.setFontSize(11);
    doc.setTextColor(100);
    doc.text(`Generado el: ${new Date().toLocaleString()}`, 14, 30);

    const tableData = HOURS.map(hour => {
      const rowData = [formatHour(hour)];
      DAYS.forEach((_, dayIndex) => {
        const blockUsers = schedule
          .filter(s => s.day === dayIndex && s.hour === hour)
          .map(s => s.username)
          .join('\n');
        rowData.push(blockUsers || '-');
      });
      return rowData;
    });

    autoTable(doc, {
      head: [['Hora', ...DAYS]],
      body: tableData,
      startY: 40,
      styles: {
        fontSize: 9,
        cellPadding: 3,
        lineColor: [200, 200, 200],
        lineWidth: 0.1,
      },
      headStyles: {
        fillColor: [79, 70, 229],
        textColor: 255,
        fontStyle: 'bold',
        halign: 'center'
      },
      bodyStyles: {
        valign: 'middle'
      },
      columnStyles: {
        0: { fontStyle: 'bold', halign: 'center', cellWidth: 25 }
      },
      theme: 'grid'
    });

    doc.save('ikai-vanguard-cronograma.pdf');
  };

  if (loading && schedule.length === 0) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-semibold text-white">Cronograma de Moderación</h2>
          <p className="text-sm text-gray-400 mt-1">Máximo 4 administradores por bloque horario.</p>
        </div>
        <button
          onClick={generatePDF}
          className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 rounded-xl text-sm font-semibold text-white transition-all shadow-lg shadow-indigo-500/20"
        >
          <Download className="w-4 h-4" />
          Exportar PDF
        </button>
      </div>

      <div className="bg-[#141414] border border-white/5 rounded-3xl overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-gray-400 uppercase bg-[#0a0a0a] border-b border-white/5">
              <tr>
                <th className="px-4 py-5 font-medium text-center w-28 sticky left-0 bg-[#0a0a0a] z-10 border-r border-white/5">Hora</th>
                {DAYS.map(day => (
                  <th key={day} className="px-4 py-5 font-medium text-center min-w-[160px]">{day}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {HOURS.map(hour => (
                <tr key={hour} className="hover:bg-white/[0.02] transition-colors">
                  <td className="px-4 py-4 text-center font-mono text-gray-400 sticky left-0 bg-[#141414] z-10 border-r border-white/5">
                    {formatHour(hour)}
                  </td>
                  {DAYS.map((_, dayIndex) => {
                    const blockUsers = schedule.filter(s => s.day === dayIndex && s.hour === hour);
                    const isAssigned = blockUsers.some(s => s.user_id === user.id);
                    const isFull = blockUsers.length >= 4;
                    const isActionLoading = actionLoading?.day === dayIndex && actionLoading?.hour === hour;

                    return (
                      <td key={`${dayIndex}-${hour}`} className="px-3 py-3 border-r border-white/5 last:border-r-0">
                        <div className="flex flex-col gap-3 h-full justify-between">
                          <div className="flex flex-wrap gap-1.5 min-h-[28px]">
                            {blockUsers.map(s => (
                              <span
                                key={s.id}
                                className={`text-[11px] px-2 py-1 rounded-md truncate max-w-full font-medium ${
                                  s.user_id === user.id
                                    ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                                    : 'bg-white/5 text-gray-300 border border-white/10'
                                }`}
                                title={s.username}
                              >
                                {s.username}
                              </span>
                            ))}
                          </div>
                          <button
                            onClick={() => toggleAssignment(dayIndex, hour, isAssigned)}
                            disabled={isActionLoading || (!isAssigned && isFull)}
                            className={`w-full py-2 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
                              isAssigned
                                ? 'bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20'
                                : isFull
                                ? 'bg-[#0a0a0a] text-gray-600 cursor-not-allowed border border-white/5'
                                : 'bg-white/5 text-gray-300 hover:bg-white/10 border border-white/10'
                            }`}
                          >
                            {isActionLoading ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            ) : isAssigned ? (
                              'Quitarme'
                            ) : isFull ? (
                              'Lleno'
                            ) : (
                              'Asignarme'
                            )}
                          </button>
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
